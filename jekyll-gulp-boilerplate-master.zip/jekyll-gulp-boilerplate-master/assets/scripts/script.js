console.log("A boilerplate project including full setup for Jekyll, GulpJS, SASS, PostCSS, BrowserSync and deploy to gh-pages using Gulp by Esau Silva.");
